package com.example.pathfinding;

import java.util.*;

public class AstarAlgorithm {

    public static List<Node> findPath(Node start, Node goal, int[][] grid) {
        int rows = grid.length;    // Rows correspond to Y-axis
        int cols = grid[0].length; // Columns correspond to X-axis

        PriorityQueue<Node> openSet = new PriorityQueue<>();
        Map<String, Node> allNodes = new HashMap<>(); // Key: "x,y", Value: Node

        start.gCost = 0;
        openSet.add(start);
        allNodes.put(nodeKey(start.x, start.y), start);

        while (!openSet.isEmpty()) {
            Node current = openSet.poll();

            // Check if goal is reached
            if (current.equals(goal)) {
                return reconstructPath(current);
            }

            current.visited = true;

            // Iterate through neighbors
            for (int[] direction : new int[][]{
                    {0, -1}, {0, 1}, {-1, 0}, {1, 0},  // Cardinal directions
                    {-1, -1}, {-1, 1}, {1, -1}, {1, 1} // Diagonal directions
            }) {
                int neighborX = current.x + direction[0];
                int neighborY = current.y + direction[1];

                // Skip invalid positions or non-walkable nodes
                if (!isValidPosition(neighborY, neighborX, rows, cols) || grid[neighborY][neighborX] == 1) {
                    continue;
                }

                Node neighbor = allNodes.computeIfAbsent(nodeKey(neighborX, neighborY), k -> new Node(neighborX, neighborY));
                if (neighbor.visited) {
                    continue; // Skip already visited nodes
                }

                // Calculate proximity cost (penalize nodes near walls)
                int proximityCost = calculateProximityCost(neighbor, grid);

                // Calculate the tentative gCost (cost from start to neighbor)
                int tentativeGCost = current.gCost + proximityCost;

                // If a better path to the neighbor is found, update it
                if (tentativeGCost < neighbor.gCost) {
                    neighbor.gCost = tentativeGCost;
                    neighbor.hCost = calculateHCost(neighbor, goal);
                    neighbor.parent = current;

                    if (!openSet.contains(neighbor)) {
                        openSet.add(neighbor);
                    }
                }
            }
        }

        // Return empty list if no path is found
        return new ArrayList<>();
    }

    private static String nodeKey(int x, int y) {
        return x + "," + y;
    }

    private static List<Node> reconstructPath(Node current) {
        List<Node> path = new ArrayList<>();
        while (current != null) {
            path.add(current);
            current = current.parent;
        }
        Collections.reverse(path);
        return path;
    }

    private static boolean isValidPosition(int y, int x, int rows, int cols) {
        return x >= 0 && y >= 0 && x < cols && y < rows;
    }

    private static int calculateHCost(Node from, Node to) {
        return Math.abs(from.x - to.x) + Math.abs(from.y - to.y); // Manhattan distance
    }

    /**
     * Calculate the proximity cost to encourage paths further from walls.
     *
     * @param node The current node.
     * @param grid The grid representing the map.
     * @return The proximity cost.
     */
    private static int calculateProximityCost(Node node, int[][] grid) {
        int baseCost = 10; // Base movement cost
        int wallProximityPenalty = 0;
        int radius = 30; // Radius to check around the node for walls

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                int neighborX = node.x + dx;
                int neighborY = node.y + dy;

                // Ensure the neighbor is within bounds
                if (isValidPosition(neighborY, neighborX, grid.length, grid[0].length)) {
                    // Penalty decreases with distance from the node
                    int distance = Math.abs(dx) + Math.abs(dy);
                    if (grid[neighborY][neighborX] == 1 && distance > 0) {
                        wallProximityPenalty += 5 / distance; // Add penalty inversely proportional to distance
                    }
                }
            }
        }

        return baseCost + wallProximityPenalty;
    }

}
