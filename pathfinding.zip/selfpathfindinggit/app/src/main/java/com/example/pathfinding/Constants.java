package com.example.pathfinding;

import android.graphics.PointF;

public class Constants {

    public static PointF startPoint;
    public static PointF endPoint;
    public static int mapwidth;
    public static int mapheight;
}
